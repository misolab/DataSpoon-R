# winter_df <- read_csv("medals_winter.csv")
# head(winter_df)
# 
# winter_df <- winter_df %>%
#   group_by(Year, NOC, Medal) %>% 
#   summarise(n = n())
# 
# ggplot(winter_df, aes(x=Year, y=n, fill=NOC)) +
#   geom_bar(stat = "identity", position = "dodge") +
#   facet_wrap(~NOC)