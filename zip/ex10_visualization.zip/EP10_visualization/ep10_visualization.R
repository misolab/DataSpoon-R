###################
# 라인그래프
###################
library(tidyverse)
library(ggthemes)

line_df <- read_csv("import.csv")
glimpse(line_df)

ggplot(line_df, aes(x=year, y=kg, color=category, group=category)) +
  geom_line(stat = "identity") +
  theme_fivethirtyeight() +
  scale_y_continuous(labels = scales::comma)

# dollar와 kg을 같이 그리고 싶다면?
line_df2 <- line_df %>%
  gather(category2, value, 3:4)

ggplot(line_df2, aes(x=year, y=value, color=category2, group=category2)) +
  geom_line(stat = "identity")

# area chart
ggplot(line_df2, aes(x=year, y=value, group=category2, fill=category2)) +
  geom_area(stat = "identity", alpha = .7) +
  scale_y_continuous(labels = scales::comma) +
  theme_woons()

# facet_wray
total_df <- read_csv("total.csv")
total_df <- total_df %>%
  select(-1)

unique(total_df2$category)

total_df2 <- total_df %>%
  filter(category %in% c("고등어", "갈치", "살오징어(오징어)", "미역류", "대게", "방어류", "정어리")) %>% 
  group_by(category, years) %>% 
  summarise(total = sum(value))
head(total_df2)
  
ggplot(total_df2, aes(x=years, y=total, group=category)) +
  geom_line(stat = "identity", color = "#76A665") +
  theme_woons() +
  geom_smooth(method = "loess", color = "#FFDD5C", size = 1) +
  scale_y_continuous(labels = scales::comma) +
  facet_wrap(~category, nrow = 3) +
  ggtitle("연근해 어업량 현황 1970-2016")


# 실습
# medals_winter.csv를 가져와서
# 연도별, 국가별 메달수를 카운트한 뒤에
# facet_wrap을 활용하여 국가별로 Bar Chart를 만들어보세요

